# Scuole Senza Frontiere

Questo repository contiene il sito web del progetto educativo "Scuole Senza Frontiere", ideato da ScuolAttiva Onlus in collaborazione con Medici Senza Frontiere.

Per pubblicarlo su GitHub Pages:
1. Carica tutti i file nella root del repository
2. Vai su Settings > Pages
3. Seleziona il branch `main` e la cartella `/ (root)`
4. Salva e visita il link fornito
